package dexter;


public class PeaceDeck extends Deck {
	
	public PeaceDeck() {

	}

}
