package dexter;

public class PeaceCard extends Card {

	@Override public boolean winner(Card c) {	
		
	}
}
