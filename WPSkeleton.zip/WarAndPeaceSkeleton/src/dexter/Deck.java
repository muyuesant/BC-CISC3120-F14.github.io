package dexter;

public class Deck {
	static final int DECKSIZE = 52;

	protected Card [] theDeck;


	public Deck() {

	}

	public Card draw() {

	}


}
