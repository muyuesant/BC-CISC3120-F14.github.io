package dexter;

public class Card {
	private CardValue value;
	private CardSuit suit;
	
	public String toString() {
		
	}
	

	public boolean winner(Card c) {
		
	
		
	}
	


}
