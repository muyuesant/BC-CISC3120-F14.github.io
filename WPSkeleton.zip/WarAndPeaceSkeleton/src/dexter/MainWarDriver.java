package dexter;

public class MainWarDriver {

	static final int HANDS = 52;
	
	public static void main(String[] args) {

		Deck player1 = new Deck();
		Deck player2 = new Deck();
		
		int player1Score = 0, player2Score = 0;
		
		// gameplay
		
		
		System.out.printf("Final score: Player 1--%d; Player 2--%d", player1Score, player2Score);
		
		
	}

}
