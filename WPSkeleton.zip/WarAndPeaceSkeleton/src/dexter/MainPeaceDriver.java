package dexter;
	
public class MainPeaceDriver {

	static final int HANDS = 52;
	
	public static void main(String[] args) {

		PeaceDeck player1 = new PeaceDeck();
		PeaceDeck player2 = new PeaceDeck();
		
		int player1Score = 0, player2Score = 0;
		
		// gameplay
		
		System.out.printf("Final score: Player 1--%d; Player 2--%d", player1Score, player2Score);
		
	}

}
