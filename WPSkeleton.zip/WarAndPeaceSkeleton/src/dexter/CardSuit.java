package dexter;

public enum CardSuit {
	Clubs, Diamonds, Hearts, Spades
}
